print("Empty tuple")
my_tuple=()
print(my_tuple)

print("tuple having integers")
my_tuple=(1,2,3)
print(my_tuple)

print("tuple with mixed datatypes")

my_tuple=(1,"Hello",3.4)
print(my_tuple)

print("nested tuple")

my_tuple=("mouse",(8,4,6),(1,2,3))
print(my_tuple)

my_tuple=3,4.6,"dog"
print(my_tuple)

print("tuple unpacking")
a,b,c=my_tuple
print(a)
print(b)
print(c)