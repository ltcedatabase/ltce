import math
def cube(x):
	return x**3
a=25
print("a=",a)
a=abs(a)
print("Absolute value of",a,"=",a)
print("square root of",a,"=",math.sqrt(a))
print("Power of a=",math.pow(a,4))
print("Cube of a",a,"=",cube(a))