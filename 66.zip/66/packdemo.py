from pythonpackage import first,second
first.display1()
second.display2()