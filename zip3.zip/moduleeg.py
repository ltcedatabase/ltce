import calendar
print(calendar.month(2019,3))