#10-i:-  Perl program to demonstrate the string operations 
# Concatenation and Repetition  
# Assignment Operator in String 
#!/usr/bin/perl 
# Input first string  
$string1 = "Welcome ";  
# Input second string  
$string2 = "to the world of perl";   
$combine = $string1;    
 # combine two string function (.=) 
$combine .= $string2;   
# Display result 
print $combine; 
$str_result = "Hello "; 
# Repetation operator(x) 
$str_result x= 5;  
# Display output 
print("\nprint string 5 times"); 
print "\n$str_result"; 
