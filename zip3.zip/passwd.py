import getpass
password=getpass.getpass(prompt="Enter the password")
if password=='ostl':
	print("Welcome to world of python programming")
else:
	print("Incorrect password-----Sorry you cannot read our book")